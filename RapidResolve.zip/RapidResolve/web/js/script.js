/* ----------------------------------------------------------
   Original feature: password generator (unchanged logic)
   ---------------------------------------------------------- */
function generatePassword() {

    const characters =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ" +
        "abcdefghijklmnopqrstuvwxyz" +
        "0123456789" +
        "!@#$%^&*()_+-=";

    let password = "";

    for (let i = 0; i < 16; i++) {

        const randomIndex =
            Math.floor(
                Math.random() * characters.length
            );

        password += characters[randomIndex];
    }

    const passwordField =
        document.getElementById("password");

    if (passwordField) {

        passwordField.value = password;

        passwordField.type = "text";

        if (window.syncReveal) {
            window.syncReveal(passwordField);
        }
    }
}

/* ----------------------------------------------------------
   UI enhancements (design only)
   ---------------------------------------------------------- */
(function () {

    function icon(name) {
        var s = document.createElement("span");
        s.className = "ico ico-" + name;
        s.setAttribute("aria-hidden", "true");
        return s;
    }

    function wrap(input) {
        var box = document.createElement("div");
        box.className = "field";
        input.parentNode.insertBefore(box, input);
        box.appendChild(input);
        return box;
    }

    /* Show / hide button for password fields */
    window.syncReveal = function (input) {
        var btn = input.parentNode.querySelector(".reveal");
        if (!btn) { return; }
        var shown = input.type === "text";
        btn.setAttribute("aria-label", shown ? "Hide password" : "Show password");
        btn.replaceChild(icon(shown ? "eye-off" : "eye"), btn.firstChild);
    };

    document.querySelectorAll('input[type="password"]').forEach(function (input) {
        var box = wrap(input);
        var btn = document.createElement("button");
        btn.type = "button";
        btn.className = "reveal";
        btn.appendChild(icon("eye"));
        btn.addEventListener("click", function () {
            input.type = input.type === "password" ? "text" : "password";
            window.syncReveal(input);
        });
        box.appendChild(btn);
        window.syncReveal(input);
    });

    /* Copy button for read-only detail fields */
    document.querySelectorAll("input[data-copy]").forEach(function (input) {
        var box = wrap(input);
        var btn = document.createElement("button");
        btn.type = "button";
        btn.className = "reveal";
        btn.setAttribute("aria-label", "Copy");
        btn.appendChild(icon("copy"));
        btn.addEventListener("click", function () {
            function done() {
                btn.replaceChild(icon("check"), btn.firstChild);
                setTimeout(function () {
                    btn.replaceChild(icon("copy"), btn.firstChild);
                }, 1500);
            }
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(input.value).then(done);
            } else {
                input.select();
                document.execCommand("copy");
                done();
            }
        });
        box.appendChild(btn);
    });

    /* Messages from redirects such as login.html?error=invalid */
    var box = document.getElementById("alert");

    if (box) {
        var q = new URLSearchParams(window.location.search);

        var errors = {
            invalid:  "Incorrect email or password. Check your details and try again.",
            empty:    "Fill in all the fields to continue.",
            email:    "An account with this email already exists. Log in instead.",
            insert:   "We couldn't save this password. Try again.",
            database: "Something went wrong on our side. Try again in a moment."
        };

        var type = "error";
        var text = errors[q.get("error")];

        if (!text && q.get("registered") === "true") {
            type = "success";
            text = "Account created. Log in to continue.";
        }

        if (text) {
            box.className = "alert " + type;
            box.appendChild(icon(type === "error" ? "alert" : "check-circle"));
            var span = document.createElement("span");
            span.textContent = text;
            box.appendChild(span);
            box.hidden = false;
        }
    }

})();

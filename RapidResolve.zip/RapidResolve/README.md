# RapidResolve – Real-Time Problem Reporting & Resolution System

This project is intentionally structured in the same style as the supplied PasswordProtectionManagementSystem reference: **NetBeans Web Application + JSP + Java Servlets + MySQL + dark modern UI**.

## Stack
HTML, CSS, JavaScript, JSP, Java Servlet (Jakarta), MySQL, BCrypt, Tomcat 10+, JDK 21.

## Modules
- Landing page
- User registration/login
- User dashboard
- Problem reporting
- Problem tracking
- Delete own report
- Admin control center
- Admin status/remark updates
- Pending / In Progress / Resolved / Rejected workflow

## NetBeans Setup
1. Extract the ZIP.
2. Open the `RapidResolve` folder in NetBeans as an existing project.
3. Use JDK 21 and Tomcat 10.x.
4. Ensure MySQL is running.
5. Import `database/rapidresolve.sql` in MySQL/phpMyAdmin.
6. `DBConnection.java` uses MySQL user `root` with an empty password. Change it if your MySQL password is different.
7. Run the project.

## Admin
Email: admin@rapidresolve.com
Password: admin123

## Important
The project includes `web/WEB-INF/lib/jbcrypt-0.4.jar` and MySQL Connector/J 9.6.0 from the supplied reference project, so the project does not depend on a random external jar path.

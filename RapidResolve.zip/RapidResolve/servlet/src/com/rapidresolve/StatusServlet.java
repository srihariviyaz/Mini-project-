package com.rapidresolve;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/status")
public class StatusServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        String id = request.getParameter("id");
        if (id == null || id.isBlank()) {
            out.print("{\"error\":\"Please provide a problem id\"}");
            return;
        }
        // Demo servlet endpoint. Connect this to MySQL using JDBC in deployment.
        out.print("{\"problemId\":\"" + escape(id) + "\",\"service\":\"RapidResolve\",\"message\":\"Status service is active\"}");
    }

    private String escape(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
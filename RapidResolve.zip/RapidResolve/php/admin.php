<?php require 'config.php'; if(($_SESSION["role"]??"")!=="admin"){header("Location: admin_login.php");exit;}
if($_SERVER["REQUEST_METHOD"]==="POST"){
 $id=(int)$_POST["id"];$status=$_POST["status"];$remark=trim($_POST["remark"]);
 $stmt=$conn->prepare("UPDATE problems SET status=?,admin_remark=? WHERE id=?");$stmt->bind_param("ssi",$status,$remark,$id);$stmt->execute();
}
$total=$conn->query("SELECT COUNT(*) c FROM problems")->fetch_assoc()["c"];
$pending=$conn->query("SELECT COUNT(*) c FROM problems WHERE status='Pending'")->fetch_assoc()["c"];
$resolved=$conn->query("SELECT COUNT(*) c FROM problems WHERE status='Resolved'")->fetch_assoc()["c"];
$res=$conn->query("SELECT p.*,u.name,u.email FROM problems p JOIN users u ON p.user_id=u.id ORDER BY p.updated_at DESC"); ?>
<!DOCTYPE html><html><head><title>Admin Dashboard</title><link rel="stylesheet" href="style.css"></head><body>
<div class="nav"><div class="brand">⚡ RapidResolve Admin</div><a href="logout.php">Logout</a></div><div class="container"><h2>Admin Dashboard</h2>
<div class="grid"><div class="card"><div class="stats"><?=$total?></div><div>Total Reports</div></div><div class="card"><div class="stats"><?=$pending?></div><div>Pending</div></div><div class="card"><div class="stats"><?=$resolved?></div><div>Resolved</div></div></div>
<div class="table-wrap"><table class="table"><tr><th>ID</th><th>User</th><th>Problem</th><th>Location</th><th>Priority</th><th>Status</th><th>Action</th></tr>
<?php while($p=$res->fetch_assoc()):?><tr><td>#<?=$p["id"]?></td><td><?=htmlspecialchars($p["name"])?><br><small><?=$p["email"]?></small></td><td><b><?=htmlspecialchars($p["title"])?></b><br><?=htmlspecialchars($p["description"])?></td><td><?=htmlspecialchars($p["location"])?></td><td><?=$p["priority"]?></td><td><?=$p["status"]?></td><td><form method="post"><input type="hidden" name="id" value="<?=$p["id"]?>"><select name="status"><option <?=$p["status"]==="Pending"?"selected":""?>>Pending</option><option <?=$p["status"]==="In Progress"?"selected":""?>>In Progress</option><option <?=$p["status"]==="Resolved"?"selected":""?>>Resolved</option><option <?=$p["status"]==="Rejected"?"selected":""?>>Rejected</option></select><input name="remark" placeholder="Admin remark" value="<?=htmlspecialchars($p["admin_remark"]??"")?>"><button class="btn">Update</button></form></td></tr><?php endwhile;?></table></div></div></body></html>
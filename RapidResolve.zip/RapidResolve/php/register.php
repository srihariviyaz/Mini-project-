<?php require 'config.php';
$msg="";
if($_SERVER["REQUEST_METHOD"]==="POST"){
 $name=trim($_POST["name"]); $email=trim($_POST["email"]); $password=$_POST["password"];
 if($name && filter_var($email,FILTER_VALIDATE_EMAIL) && strlen($password)>=6){
  $hash=password_hash($password,PASSWORD_DEFAULT);
  $stmt=$conn->prepare("INSERT INTO users(name,email,password) VALUES(?,?,?)");
  $stmt->bind_param("sss",$name,$email,$hash);
  if($stmt->execute()){ header("Location: login.php?registered=1"); exit; }
  $msg="Email already exists.";
 } else $msg="Enter valid details. Password must be at least 6 characters.";
} ?>
<!DOCTYPE html><html><head><title>Register</title><link rel="stylesheet" href="style.css"></head><body>
<div class="nav"><div class="brand">⚡ RapidResolve</div><a href="login.php">Login</a></div>
<div class="card form"><h2>Create Account</h2><?php if($msg):?><div class="msg err"><?=htmlspecialchars($msg)?></div><?php endif;?>
<form method="post"><label>Name</label><input name="name" required><label>Email</label><input type="email" name="email" required><label>Password</label><input type="password" name="password" minlength="6" required><button class="btn">Register</button></form></div></body></html>
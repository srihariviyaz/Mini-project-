<?php require 'config.php'; ?>
<!DOCTYPE html><html><head><title>RapidResolve</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="nav"><div class="brand">⚡ RapidResolve</div><div>
<a href="index.php">Home</a><a href="login.php">Login</a><a href="register.php">Register</a><a href="admin_login.php">Admin</a></div></div>
<div class="container"><section class="hero"><h1>RapidResolve</h1><p>Real-Time Problem Reporting & Resolution System. Report issues, track progress and help your community resolve problems faster.</p><a class="btn" href="register.php">Get Started</a></section>
<div class="grid" style="margin-top:25px"><div class="card"><h3>📢 Report</h3><p>Submit problems with category, location, priority and description.</p></div><div class="card"><h3>🔎 Track</h3><p>Follow the current status of every problem you reported.</p></div><div class="card"><h3>⚡ Resolve</h3><p>Admins review reports and update progress until resolution.</p></div></div></div>
<div class="footer">RapidResolve • IP Mini Project</div></body></html>
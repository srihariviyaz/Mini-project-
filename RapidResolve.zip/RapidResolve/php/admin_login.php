<?php require 'config.php';
if($_SERVER["REQUEST_METHOD"]==="POST"){
 $email=trim($_POST["email"]);$password=$_POST["password"];
 $stmt=$conn->prepare("SELECT id,name,password,role FROM users WHERE email=? AND role='admin'");$stmt->bind_param("s",$email);$stmt->execute();$u=$stmt->get_result()->fetch_assoc();
 if($u && password_verify($password,$u["password"])){$_SESSION["user_id"]=$u["id"];$_SESSION["name"]=$u["name"];$_SESSION["role"]="admin";header("Location: admin.php");exit;}
 $msg="Invalid admin credentials.";
} ?>
<!DOCTYPE html><html><head><title>Admin Login</title><link rel="stylesheet" href="style.css"></head><body>
<div class="nav"><div class="brand">⚡ RapidResolve Admin</div><a href="index.php">Home</a></div>
<div class="card form"><h2>Admin Login</h2><?php if(isset($msg)):?><div class="msg err"><?=$msg?></div><?php endif;?>
<form method="post"><label>Email</label><input type="email" name="email" required><label>Password</label><input type="password" name="password" required><button class="btn dark">Admin Login</button></form><p class="muted">Demo: admin@rapidresolve.com / admin123</p></div></body></html>
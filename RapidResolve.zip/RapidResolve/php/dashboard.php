<?php require 'config.php'; if(!isset($_SESSION["user_id"])) {header("Location: login.php");exit;}
$stmt=$conn->prepare("SELECT * FROM problems WHERE user_id=? ORDER BY created_at DESC");$stmt->bind_param("i",$_SESSION["user_id"]);$stmt->execute();$res=$stmt->get_result(); ?>
<!DOCTYPE html><html><head><title>Dashboard</title><link rel="stylesheet" href="style.css"></head><body>
<div class="nav"><div class="brand">⚡ RapidResolve</div><div><a href="report.php">Report</a><a href="dashboard.php">My Reports</a><a href="logout.php">Logout</a></div></div>
<div class="container"><h2>Welcome, <?=htmlspecialchars($_SESSION["name"])?></h2><div class="top-actions"><a class="btn" href="report.php">+ New Problem</a></div>
<div class="table-wrap"><table class="table"><tr><th>ID</th><th>Problem</th><th>Category</th><th>Location</th><th>Priority</th><th>Status</th><th>Updated</th></tr>
<?php while($p=$res->fetch_assoc()): $cls=str_replace(' ','',$p["status"]); ?><tr><td>#<?=$p["id"]?></td><td><?=htmlspecialchars($p["title"])?><br><small><?=htmlspecialchars($p["description"])?></small></td><td><?=htmlspecialchars($p["category"])?></td><td><?=htmlspecialchars($p["location"])?></td><td><?=htmlspecialchars($p["priority"])?></td><td><span class="badge <?=$cls?>"><?=htmlspecialchars($p["status"])?></span></td><td><?=$p["updated_at"]?></td></tr><?php endwhile;?>
</table></div></div></body></html>
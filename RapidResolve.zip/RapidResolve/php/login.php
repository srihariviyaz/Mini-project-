<?php require 'config.php';
if(isset($_SESSION["user_id"])) header("Location: dashboard.php");
$msg=isset($_GET["registered"])?"Registration successful. Please login.":"";
if($_SERVER["REQUEST_METHOD"]==="POST"){
 $email=trim($_POST["email"]); $password=$_POST["password"];
 $stmt=$conn->prepare("SELECT id,name,password,role FROM users WHERE email=?");
 $stmt->bind_param("s",$email); $stmt->execute(); $res=$stmt->get_result(); $u=$res->fetch_assoc();
 if($u && password_verify($password,$u["password"])){
  $_SESSION["user_id"]=$u["id"]; $_SESSION["name"]=$u["name"]; $_SESSION["role"]=$u["role"];
  header("Location: ".($u["role"]==="admin"?"admin.php":"dashboard.php")); exit;
 } $msg="Invalid email or password.";
} ?>
<!DOCTYPE html><html><head><title>Login</title><link rel="stylesheet" href="style.css"></head><body>
<div class="nav"><div class="brand">⚡ RapidResolve</div><a href="register.php">Register</a></div>
<div class="card form"><h2>User Login</h2><?php if($msg):?><div class="msg <?=str_contains($msg,'Invalid')?'err':''?>"><?=htmlspecialchars($msg)?></div><?php endif;?>
<form method="post"><label>Email</label><input type="email" name="email" required><label>Password</label><input type="password" name="password" required><button class="btn">Login</button></form></div></body></html>
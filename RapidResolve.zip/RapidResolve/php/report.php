<?php require 'config.php'; if(!isset($_SESSION["user_id"])) {header("Location: login.php");exit;}
$msg="";
if($_SERVER["REQUEST_METHOD"]==="POST"){
 $title=trim($_POST["title"]);$cat=$_POST["category"];$loc=trim($_POST["location"]);$desc=trim($_POST["description"]);$pri=$_POST["priority"];
 $stmt=$conn->prepare("INSERT INTO problems(user_id,title,category,location,description,priority) VALUES(?,?,?,?,?,?)");
 $stmt->bind_param("isssss",$_SESSION["user_id"],$title,$cat,$loc,$desc,$pri);
 if($stmt->execute()) $msg="Problem reported successfully. ID #".$stmt->insert_id; else $msg="Could not submit report.";
} ?>
<!DOCTYPE html><html><head><title>Report Problem</title><link rel="stylesheet" href="style.css"></head><body>
<div class="nav"><div class="brand">⚡ RapidResolve</div><div><a href="dashboard.php">Dashboard</a><a href="logout.php">Logout</a></div></div>
<div class="card form"><h2>Report a Problem</h2><?php if($msg):?><div class="msg"><?=htmlspecialchars($msg)?></div><?php endif;?>
<form method="post"><label>Problem Title</label><input name="title" required><label>Category</label><select name="category"><option>Road</option><option>Water</option><option>Electricity</option><option>Sanitation</option><option>Public Safety</option><option>Other</option></select><label>Location</label><input name="location" required><label>Priority</label><select name="priority"><option>Low</option><option selected>Medium</option><option>High</option></select><label>Description</label><textarea name="description" required></textarea><button class="btn">Submit Report</button></form></div></body></html>
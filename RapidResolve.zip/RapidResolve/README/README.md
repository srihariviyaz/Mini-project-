# RapidResolve – Real-Time Problem Reporting & Resolution System

## Technology
- HTML, CSS, JavaScript
- PHP
- MySQL
- Java Servlet (Jakarta Servlet)

## Features
- User registration and secure password hashing
- User login
- Problem reporting
- Category, location and priority
- Real-time-style status tracking through database updates
- Admin dashboard
- Admin status updates and remarks
- Responsive modern UI
- Servlet status API endpoint

## XAMPP Setup
1. Copy the `php` folder to `C:\xampp\htdocs\rapidresolve`.
2. Start Apache and MySQL in XAMPP.
3. Open phpMyAdmin.
4. Import `database/rapidresolve.sql`.
5. Open:
   http://localhost/rapidresolve/php/

### User
Register a new account from the website.

### Admin
Email: admin@rapidresolve.com
Password: admin123

## Servlet Setup
The servlet is provided as a Jakarta Servlet module for Tomcat 10+.
- Java package: `com.rapidresolve`
- Endpoint: `/status?id=1`
- Compile/package it as a WAR in NetBeans/IntelliJ/Eclipse with Jakarta Servlet API.
- Deploy to Tomcat 10+.

## Suggested Project Explanation
User reports a problem -> PHP validates and stores it in MySQL -> admin reviews it -> admin changes status -> user dashboard reads the latest database status.

## Important
Change the demo admin password before real deployment. For production, use environment variables for DB credentials and HTTPS.
